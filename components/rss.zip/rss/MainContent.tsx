import { Card, CardContent } from "@/components/ui/card";
import { RSSEntriesDisplay } from "@/components/RSSEntriesDisplay";

interface MainContentProps {
  className?: string;
}

export const MainContent = ({ className }: MainContentProps) => {
  return (
    <main className={className}>
      <RSSEntriesDisplay />
    </main>
  );
};