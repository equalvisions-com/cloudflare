import { getAuthUserId } from "@convex-dev/auth/server";
import { action, query } from "./_generated/server";
import { Redis } from '@upstash/redis';
import { api } from "./_generated/api";

interface RSSItem {
  title: string;
  link: string;
  description?: string;
  pubDate: string;
  guid: string;
  image?: string;
  feedUrl: string;
}

// Initialize Redis client with error handling
function initializeRedis() {
  const url = process.env.UPSTASH_REDIS_REST_URL;
  const token = process.env.UPSTASH_REDIS_REST_TOKEN;

  if (!url || !token) {
    throw new Error('Redis credentials not configured. Please set UPSTASH_REDIS_REST_URL and UPSTASH_REDIS_REST_TOKEN environment variables.');
  }

  return new Redis({
    url,
    token,
    automaticDeserialization: true,
  });
}

// Create Redis client
const redis = initializeRedis();

// Query to get user's RSS keys
export const getUserRSSKeys = query({
  handler: async (ctx) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) throw new Error("Not authenticated");

    const profile = await ctx.db
      .query("profiles")
      .filter((q) => q.eq(q.field("userId"), userId))
      .first();

    return profile?.rssKeys || [];
  },
});

// Action to fetch entries from Redis
export const fetchRSSEntries = action({
  handler: async (ctx): Promise<RSSItem[]> => {
    try {
      // Get the RSS keys using our query
      const rssKeys: string[] = await ctx.runQuery(api.rssKeys.getUserRSSKeys);
      
      if (rssKeys.length === 0) {
        return [];
      }

      // Keep track of seen GUIDs to prevent duplicates
      const seenGuids = new Set<string>();

      // Fetch entries from Redis for each RSS key
      const allEntries = await Promise.all(
        rssKeys.map(async (rssKey: string) => {
          try {
            const entries: unknown[] = await redis.lrange(rssKey, 0, -1);
            console.log(`Fetched ${entries.length} entries for key ${rssKey}`);
            
            // Filter and validate entries, removing duplicates
            return entries.filter((entry): entry is RSSItem => {
              if (!entry || typeof entry !== 'object') return false;
              const item = entry as Partial<RSSItem>;
              
              // Check if this is a valid item with required fields
              const isValid = !!(
                item.title &&
                item.link &&
                item.pubDate &&
                item.guid &&
                item.feedUrl
              );

              if (!isValid) return false;

              // Since we checked item.guid exists in isValid, we can safely use it
              const guid = item.guid as string;

              // Check for duplicates
              if (seenGuids.has(guid)) {
                console.log(`Duplicate entry found: ${item.title}`);
                return false;
              }

              seenGuids.add(guid);
              return true;
            });
          } catch (error) {
            console.error(`Error fetching entries for key ${rssKey}:`, error);
            return [];
          }
        })
      );

      // Flatten and sort all entries by date
      const flattenedEntries = allEntries.flat();
      console.log(`Total unique entries: ${flattenedEntries.length}`);

      return flattenedEntries.sort((a, b) => 
        new Date(b.pubDate).getTime() - new Date(a.pubDate).getTime()
      );
    } catch (error) {
      console.error('Error in fetchRSSEntries:', error);
      return [];
    }
  },
}); 