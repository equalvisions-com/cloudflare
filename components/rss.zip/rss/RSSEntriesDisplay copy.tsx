'use client';

import { useAction, useQuery } from "convex/react";
import { api } from "../convex/_generated/api";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import Image from "next/image";
import { formatDistanceToNow } from "date-fns";
import { useState, useEffect } from "react";

interface RSSItem {
  title: string;
  link: string;
  description?: string;
  pubDate: string;
  guid: string;
  image?: string;
  feedUrl: string;
}

export function RSSEntriesDisplay() {
  const fetchEntries = useAction(api.rssKeys.fetchRSSEntries);
  const rssKeys = useQuery(api.rssKeys.getUserRSSKeys);
  const [entries, setEntries] = useState<RSSItem[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const loadEntries = async () => {
      if (rssKeys && rssKeys.length > 0) {
        setLoading(true);
        const fetchedEntries = await fetchEntries();
        setEntries(fetchedEntries);
        setLoading(false);
      } else {
        setLoading(false);
      }
    };

    loadEntries();
  }, [rssKeys, fetchEntries]);

  if (loading) {
    return (
      <div className="flex justify-center items-center h-full min-h-[200px]">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
      </div>
    );
  }

  if (!rssKeys?.length) {
    return (
      <div className="text-center py-8 text-muted-foreground">
        No RSS feeds found. Add some feeds to get started.
      </div>
    );
  }

  if (!entries.length) {
    return (
      <div className="text-center py-8 text-muted-foreground">
        No entries found in your RSS feeds.
      </div>
    );
  }

  return (
    <div className="space-y-4">
      {entries.map((entry) => (
        <Card key={entry.guid} className="overflow-hidden hover:shadow-lg transition-shadow">
          <a href={entry.link} target="_blank" rel="noopener noreferrer" className="flex gap-4">
            {entry.image && (
              <div className="relative w-48 h-32 flex-shrink-0">
                <Image
                  src={entry.image}
                  alt={entry.title}
                  fill
                  className="object-cover"
                  sizes="(max-width: 768px) 192px, 192px"
                />
              </div>
            )}
            <div className="flex-1 p-4">
              <h3 className="font-semibold line-clamp-2 hover:text-primary transition-colors mb-2">
                {entry.title}
              </h3>
              {entry.description && (
                <p className="text-muted-foreground text-sm line-clamp-2 mb-2">
                  {entry.description}
                </p>
              )}
              <div className="text-xs text-muted-foreground">
                {formatDistanceToNow(new Date(entry.pubDate), { addSuffix: true })}
              </div>
            </div>
          </a>
        </Card>
      ))}
    </div>
  );
} 